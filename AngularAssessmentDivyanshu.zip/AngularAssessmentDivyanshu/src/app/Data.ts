export interface Data {
    id?: any;
    movieName: any;
    movieBookingDate: any;
    noOfTickets: any;
    totalAmount: any;
}