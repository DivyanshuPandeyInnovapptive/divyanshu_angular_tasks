import { Component } from '@angular/core';
import { increment } from 'src/app/store/actions/count.actions';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {

  constructor(private store: Store<{count: number}>) {}

  increment() {
    this.store.dispatch(increment());
  }
}
