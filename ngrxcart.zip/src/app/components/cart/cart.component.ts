import { Component } from '@angular/core';
import { Update } from '@ngrx/entity';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Product } from 'src/app/model/product.model';
import { ApiService } from 'src/app/services/api.service';
import { productActionTypes } from 'src/app/store/actions/product.actions';
import { AppState } from 'src/app/store/reducers';
import { getAllProducts } from 'src/app/store/selectors/product.selectors';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent {
  items = [{id: 100, quantity: 1, price: 100}, {id: 100, quantity: 2, price: 150}, {id: 100, quantity: 1, price: 100}, {id: 100, quantity: 2, price: 150},{id: 100, quantity: 1, price: 100}, {id: 100, quantity: 2, price: 150}];

  products$: Observable<Product[]>;

  constructor(private apiService: ApiService, private store: Store<AppState>) { }

  ngOnInit() {
    this.products$ = this.store.select(getAllProducts);
  }

  updateProduct(product: Product) {
    const update: Update<Product> = {
      id: Number(product.id),
      changes: {
        quantity: product.quantity+1
      }
    };

    this.store.dispatch(productActionTypes.updateProduct({update}));
  }
}
