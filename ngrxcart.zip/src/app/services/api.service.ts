import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http"
import { Product } from '../model/product.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  http: HttpClient;

  constructor(http: HttpClient) {
    this.http = http;
  }

  getAllProducts(): Observable<Product[]> {
    return this.http.get<Product[]>('/api/products');
  }

  updateProduct(productId: string | number, changes: Partial<Product>): Observable<any> {
    return this.http.put('/api/courses/' + productId, changes);
  }
}
