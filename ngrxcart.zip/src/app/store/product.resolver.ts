import { areProductsLoaded } from './selectors/product.selectors';
import { loadProducts } from './actions/product.actions';
import { AppState } from './../store/reducers/index';
import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { Observable } from 'rxjs';
import {select, Store} from '@ngrx/store';
import {filter, first, tap} from 'rxjs/operators';

@Injectable()
export class ProductResolver implements Resolve<Observable<any>> {

  constructor(private store: Store<AppState>) {}

  resolve(): Observable<any> {
    return this.store
    .pipe(
        select(areProductsLoaded),
        tap((productsLoaded) => {
          console.log('111', productsLoaded);
          if (!productsLoaded) {
            this.store.dispatch(loadProducts());
          }

        }),
        filter(productsLoaded => productsLoaded),
        first()
    );
  }
}
