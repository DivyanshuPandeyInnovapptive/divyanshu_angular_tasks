import { productActionTypes } from '../actions/product.actions';
import { ApiService } from './../../services/api.service';
import { createEffect, Actions, ofType } from '@ngrx/effects';
import { concatMap, map } from 'rxjs/operators';
import { Injectable } from '@angular/core';

@Injectable()
export class ProductEffects {

  loadProducts$ = createEffect(() =>
    this.actions$.pipe(
      ofType(productActionTypes.loadProducts),
      concatMap(() => this.apiService.getAllProducts()),
      map(products => productActionTypes.productsLoaded({products}))
    )
  );
  
  updateProduct$ = createEffect(() =>
    this.actions$.pipe(
      ofType(productActionTypes.updateProduct),
      concatMap((action) => this.apiService.updateProduct(action.update.id, action.update.changes))
    ),
    {dispatch: false}
    );
    
    constructor(private apiService: ApiService, private actions$: Actions) {}
}
