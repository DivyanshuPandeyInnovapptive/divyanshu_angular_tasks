import { createReducer, on } from '@ngrx/store';
import { increment } from '../actions/count.actions';

export const initialState = 0;

export const countReducer = createReducer(
  initialState,
  on(increment, (state) => state + 1)
);