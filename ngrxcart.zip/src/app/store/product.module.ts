// import { ProductEffects } from './effects/product.effects';
// import { ApiService} from './../services/api.service'
// import { CommonModule } from '@angular/common';
// import { FormsModule } from '@angular/forms';
// import { NgModule } from '@angular/core';

// import { CartComponent } from '../components/cart/cart.component';
// import { StoreModule } from '@ngrx/store';
// import { EffectsModule } from '@ngrx/effects';
// import { productReducer } from './reducers/product.reducer';

// @NgModule({
//   declarations: [
//     CartComponent,
//   ],
//   imports: [
//     CommonModule,
//     FormsModule,
//     StoreModule.forFeature('products', productReducer),
//     EffectsModule.forFeature([ProductEffects])
//   ],
//   providers: [ApiService],
//   bootstrap: [],
//   exports: [CartComponent]
// })
// export class ProductModule { }
