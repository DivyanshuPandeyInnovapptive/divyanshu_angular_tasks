import { Product } from "src/app/model/product.model";
import { createAction, props } from "@ngrx/store";
import { Update } from "@ngrx/entity";

export const loadProducts = createAction(
    '[Products List] Load Products via Service',
);

export const productsLoaded = createAction(
    '[Products Effect] Products Loaded Successfully',
    props<{products: Product[]}>()
);

export const updateProduct = createAction(
    '[Products List Operations] Update Product',
    props<{update: Update<Product>}>()
);

export const productActionTypes = {
loadProducts,
updateProduct,
productsLoaded
};